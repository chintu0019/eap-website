<?php
/**
 * Deprecated. Moved to /3rd-party/ directory.
 *
 * @package Jetpack.
 */

// See 3rd-party/class.jetpack-bbpress-json-api.compat.php.
